# Mon Profil Patient - Template d'IG FHIR en Français v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mon Profil Patient**

## Resource Profile: Mon Profil Patient 

| | |
| :--- | :--- |
| *Official URL*:https://example.com/fhir/ig/template/StructureDefinition/mon-profil | *Version*:1.0.0 |
| Draft as of 2025-12-29 | *Computable Name*:MonProfil |

 
Un exemple de profil patient personnalisé 

**Utilisations:**

* Ce Profil nest utilisé par aucun profil dans ce guide dimplémentation

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.other.uv.template|current/StructureDefinition/mon-profil)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-mon-profil.csv), [Excel](StructureDefinition-mon-profil.xlsx), [Schematron](StructureDefinition-mon-profil.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mon-profil",
  "url" : "https://example.com/fhir/ig/template/StructureDefinition/mon-profil",
  "version" : "1.0.0",
  "name" : "MonProfil",
  "title" : "Mon Profil Patient",
  "status" : "draft",
  "date" : "2025-12-29T00:20:28+01:00",
  "publisher" : "CPage",
  "contact" : [
    {
      "name" : "CPage",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.cpage.example"
        },
        {
          "system" : "email",
          "value" : "contact@cpage.example"
        }
      ]
    }
  ],
  "description" : "Un exemple de profil patient personnalisé",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "cda",
      "uri" : "http://hl7.org/v3/cda",
      "name" : "CDA (R2)"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "loinc",
      "uri" : "http://loinc.org",
      "name" : "LOINC code for the element"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Patient",
        "path" : "Patient"
      },
      {
        "id" : "Patient.name",
        "path" : "Patient.name",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "Patient.birthDate",
        "path" : "Patient.birthDate",
        "min" : 1,
        "mustSupport" : true
      }
    ]
  }
}

```
